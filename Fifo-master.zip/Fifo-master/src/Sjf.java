import java.util.List;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

public class Sjf extends Cola{

    PriorityQueue<Procesos> listado;

    public Sjf() {
        listado = new PriorityQueue<>();
    }


    public List<Procesos> listarP(){
        return listado.stream().sorted().collect(Collectors.toList());
    }
}
