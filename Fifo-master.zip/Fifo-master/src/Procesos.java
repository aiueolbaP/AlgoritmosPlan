public class Procesos implements Comparable<Procesos>{

    private int rafaga;
    private String proceso;
    private double retorno;
    private int llegada;
    private double espera;
    private int prioridad;

    public Procesos(int rafaga, String proceso) {
        this.rafaga = rafaga;
        this.proceso = proceso;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public int getLlegada() {
        return llegada;
    }

    public void setLlegada(int llegada) {
        this.llegada = llegada;
    }

    public int getRafaga() {
        return rafaga;
    }

    public void setRafaga(int rafaga) {
        this.rafaga = rafaga;
    }

    public String getProceso() {
        return proceso;
    }

    public void setProceso(String proceso) {
        this.proceso = proceso;
    }

    public double getRetorno() {
        return retorno;
    }

    public void setRetorno(int retorno) {
        this.retorno = retorno;
    }

    public void setRetorno(double retorno) {
        this.retorno = retorno;
    }

    public double getEspera() {
        return espera;
    }

    public void setEspera(double espera) {
        this.espera = espera;
    }

    @Override
    public String toString() {
        return "Proceso: " + proceso + ", tiempo de llegada: "+ llegada+ ", rafaga: "+rafaga +"\n";
    }


    @Override
    public int compareTo(Procesos o) {
       return Integer.compare(this.rafaga, o.getRafaga());
    }

}
