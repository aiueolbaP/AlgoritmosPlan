import java.util.List;
import java.util.PriorityQueue;
import java.util.stream.Collectors;

public class Prioridad extends Cola{

    PriorityQueue<Procesos> listado;

    public Prioridad() {
        listado = new PriorityQueue<>();
    }

    public List<Procesos> listarP(){
        return listado.stream().sorted((p1,p2)-> p1.comparePri(p2)).collect(Collectors.toList());
    }
}
