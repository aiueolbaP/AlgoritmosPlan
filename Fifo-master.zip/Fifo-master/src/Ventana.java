import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Ventana {
    private JPanel principal;
    private JTextField txtProceso;
    private JTextField txtRafaga;
    private JTextArea txtShow;
    private JButton encolarButton;
    private JButton desencolarButton;
    private JTextArea txtTiempos;
    private JButton btnTiempos;
    private JComboBox cboOpcion;
    private JButton btnOpcion;
    private Cola listado = new Cola();
    private int opcion;
    private Object o;
    private Class<?> clase;
    private Method[] metodos;

    public Ventana() {

        btnOpcion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcion = Integer.parseInt((String.valueOf(cboOpcion.getSelectedItem())));

                switch (opcion){
                    case 1:
                        o = new Cola();
                        clase = Cola.class;
                        break;
                    case 2:
                        o = new Sjf();
                        clase = Sjf.class;
                }

                metodos = clase.getMethods();

            }
        });



        encolarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Method encolar = metodos[1];
                Method unir = metodos[5];


                String proceso = txtProceso.getText();
                int rafaga = Integer.parseInt(txtRafaga.getText());
                Procesos pro = new Procesos(rafaga, proceso);
                try {
                    encolar.invoke(o, pro);
                    txtShow.setText((String) unir.invoke(o));
                } catch (IllegalAccessException | InvocationTargetException ex) {
                    throw new RuntimeException(ex);
                }


            }
        });
        btnTiempos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    txtTiempos.setText(listado.calcularEspera() + listado.calcularRetorno());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
        });
        desencolarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    listado.desencolar();
                    txtShow.setText(listado.toString());
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
        });

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(700, 500);
        frame.setVisible(true);
    }

    public Object getO() {
        return o;
    }

    public void setO(Object o) {
        this.o = o;
    }
}
