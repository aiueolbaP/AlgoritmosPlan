import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Ventana {
    private JPanel principal;
    private JTextField txtProceso;
    private JTextField txtRafaga;
    private JTextArea txtShow;
    private JButton encolarButton;
    private JButton desencolarButton;
    private JTextArea txtTiempos;
    private JButton btnTiempos;
    private JComboBox cboOpcion;
    private JButton btnOpcion;
    private JLabel txtAlgo;
    //private Cola listado = new Cola();
    private int opcion;
    private Object o;
    private Class<?> clase;
    private Method[] metodos;

    public Ventana() {

        btnOpcion.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                opcion = Integer.parseInt((String.valueOf(cboOpcion.getSelectedItem())));

                switch (opcion){
                    case 1:
                        o = new Cola();
                        clase = Cola.class;
                        txtAlgo.setText("FIFO");
                        break;
                    case 2:
                        o = new Sjf();
                        clase = Sjf.class;
                        txtAlgo.setText("SJF");
                        break;
                    case 3:
                        o = new Prioridad();
                        clase = Prioridad.class;
                        txtAlgo.setText("Prioridad");
                        break;
                }

                metodos = clase.getMethods();

            }
        });



        encolarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Method encolar = null;
                Method unir = null;

                String proceso = txtProceso.getText();
                int rafaga = Integer.parseInt(txtRafaga.getText());
                Procesos pro = new Procesos(rafaga, proceso);
                try {
                    encolar = clase.getMethod("encolar", Procesos.class);
                    encolar.invoke(o, pro);
                    unir = clase.getMethod("toString");
                    txtShow.setText((String) unir.invoke(o));
                } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ex) {
                    throw new RuntimeException(ex);
                }


            }
        });
        btnTiempos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Method espera = null;
                Method retorno = null;
                Method unir = null;
                try {
                    espera = clase.getMethod("calcularEspera");
                    retorno = clase.getMethod("calcularRetorno");
                    txtTiempos.setText((String) espera.invoke(o) + (String) retorno.invoke(o));
                 //   txtTiempos.setText(listado.calcularEspera() + listado.calcularRetorno());
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }

            }
        });
        desencolarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Method desencolar = null;
                Method unir = null;
                try{
                    desencolar = clase.getMethod("desencolar");
                    unir = clase.getMethod("toString");
                    desencolar.invoke(o);
                    txtShow.setText((String) unir.invoke(o));
                }catch (Exception ex){
                    JOptionPane.showMessageDialog(null,ex.getMessage());
                }
            }
        });

    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setSize(700, 500);
        frame.setVisible(true);
    }

    public Object getO() {
        return o;
    }

    public void setO(Object o) {
        this.o = o;
    }
}
