import java.util.ArrayDeque;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.stream.Collectors;

public class Cola {

    public Queue<Procesos> listado;

    public Cola() {
        listado = new ArrayDeque<>();
    }

    public void encolar(Procesos proceso){
        listado.add(proceso);
        for( int i = 0; i < listado.size(); i++){
            proceso.setLlegada(i);
        }
    }


    public Procesos desencolar() throws Exception {
        if(listado.isEmpty())
            throw new Exception("La cola está vacía");
        return listado.poll();
    }

    public String calcularEspera() throws Exception{
        StringBuilder sb = new StringBuilder();
        float espera = 0;
        float total = 0;
        if(listado.isEmpty())
            throw new Exception("La cola está vacía\n");
        else {
            for(Procesos p: listado){
                espera = total-p.getLlegada();
                total = total+ p.getRafaga();
                p.setEspera(espera);
                sb.append("\nProceso: " + p.getProceso()+", tiempo de espera: " + p.getEspera() +"\n");

            }
            sb.append("\nPromedio de espera: " + espera/listado.size());
        }
        return sb.toString();
    }

    public String calcularRetorno() throws Exception {
        StringBuilder sb = new StringBuilder();
        float retorno = 0;
        if (listado.isEmpty())
            throw new Exception("La cola está vacía\n");
        else{
            for(Procesos p: listado){
                retorno = retorno + p.getRafaga();
                p.setRetorno(retorno);
                sb.append("\nProceso: " +p.getProceso()+", tiempo de retorno: "+ retorno +"\n");

            }
            sb.append("\nPromedio de retorno: " + retorno/listado.size());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for(Procesos p: listado){
            sb.append(p.toString());
        }
        return sb.toString();
    }
}
